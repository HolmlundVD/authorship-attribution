#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 23 19:01:28 2021

@author: fshiranichaharsooghi
"""
import sys, numpy as np,os
import Info_Theory as IT
import nltk
import math
# nltk.download('punkt')
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize

import matplotlib.pyplot as plt
import networkx as nx
import matplotlib
from datetime import datetime

Train_address='/Users/fshiranichaharsooghi/.spyder-py3/texts/Train/' 
Test_address='/Users/fshiranichaharsooghi/.spyder-py3/texts/Test/' 
len_Train_address=len(Train_address)

def train(inputfile, parameter):
    Freqs=test(inputfile)
    inputfile= inputfile[len_Train_address:]
    for root, dirs, files in os.walk('/Users/fshiranichaharsooghi/.spyder-py3/texts/Train'):
        for file in files:           
            if file.endswith('.rtf'):
                if file[0:3]!=inputfile[0:3]:
                    print(inputfile)
                    print(file)
                    print('-----')
#                if Train_address+file!=inputfile:
                    adversary=Train_address+file
                    Freqs2=test(adversary)
                    Freqs=Freqs-parameter*Freqs2
                    Freqs=np.array([np.max([c,0]) for c in Freqs])
                    norm=np.sum(Freqs)
                    Freqs=Freqs/norm
    # with open(inputfile, "rt") as inp:
    #     while(1):
    #         pos=inp.tell()
    #         symbol=inp.read(2)
    #         if not symbol:
    #             break
    #         # print(symbol)
    #         Temp=[ord(s) for s in symbol]
    #         # print(Temp)
    #         inp.seek(pos)
    #         symbol=inp.read(1)
    #         if len(Temp)==2:
    #             Freqs[Temp[0],Temp[1]]=Freqs[Temp[0],Temp[1]]+1
    #             # print(Freqs[Temp[0],Temp[1]])
    #         else:
    #             break
    # Freqs2=np.zeros((128,128))
    # with open(adversary, "rt") as inp:
    #     while(1):
    #         pos=inp.tell()
    #         symbol=inp.read(2)
    #         if not symbol:
    #             break
    #         # print(symbol)
    #         Temp=[ord(s) for s in symbol]
    #         # print(Temp)
    #         inp.seek(pos)
    #         symbol=inp.read(1)
    #         if len(Temp)==2:
    #             Freqs2[Temp[0],Temp[1]]=Freqs2[Temp[0],Temp[1]]-parameter
    #             # print(Freqs[Temp[0],Temp[1]])
    #         else:
    #             break
    # Freqs=Freqs+Freqs2
    

    return Freqs
            
def test(inputfile):
    Freqs=np.zeros((128,128))
    with open(inputfile, "rt") as inp:
        while(1):
            pos=inp.tell()
            symbol=inp.read(2)
            if not symbol:
                break
            # print(symbol)
            Temp=[ord(s) for s in symbol]
            # print(Temp)
            inp.seek(pos)
            symbol=inp.read(1)
            if len(Temp)==2:
                Freqs[Temp[0],Temp[1]]=Freqs[Temp[0],Temp[1]]+1
                # print(Freqs[Temp[0],Temp[1]])
            else:
                break
    Freqs=Freqs.ravel()
    norm=np.sum(Freqs)
    Freqs=Freqs/norm

                
    return Freqs

parameter2=.7
Texts_Train=['N_Sartre_Nausea_P1', 'N_Shakespear_Ceasar_P1', 'Hill_P1', 'BBC_P1', 'FT_P1','N_Shakespear_Hamlet_P1']
Texts_Test=['N_Sartre_Nausea_P2','N_Shakespear_Ceasar_P2','Hill_P2','BBC_P2', 'FT_P2', 'N_Shakespear_Hamlet_P2']
Names=Texts_Train
Names=np.append(Names,Texts_Test)
Texts_Range=list(Names)
# Freqs_Sartre_1=train('Sartre_P1.rtf',parameter2)+10**-15
# Freqs_Sartre_2=test('Sartre_P2.rtf')+10**-15
# Freqs_Ceasar_1=train('Ceasar_P1.rtf',parameter2)+10**-15
# Freqs_Ceasar_2=test('Ceasar_P2.rtf')+10**-15
# Freqs_Hill_1=train('News_P1.rtf',parameter2)+10**-15
# Freqs_Hill_2=test('News_P2.rtf')+10**-15
# Freqs_BBC_1=train('BBC_P1.rtf',parameter2)+10**-15
# Freqs_BBC_2=test('BBC_P2.rtf')+10**-15
# Freqs_FT_1=train('FT_P1.rtf',parameter2)+10**-15
# Freqs_FT_2=test('FT_P2.rtf')+10**-15
# Freqs_Hamlet_1=train('Hamlet_P1.rtf',parameter2)+10**-15
# Freqs_Hamlet_2=test('Hamlet_P2.rtf')+10**-15

Freqs1=np.zeros((len(Texts_Train),128*128))
Freqs1[0,:]=train(Train_address+'N_Sartre_Nausea_P1.rtf',parameter2)+10**-15
Freqs1[1,:]=train(Train_address+'N_Shakespear_Ceasar_P1.rtf',parameter2)+10**-15
Freqs1[2,:]=train(Train_address+'News_P1.rtf',parameter2)+10**-15
Freqs1[3,:]=train(Train_address+'BBC_P1.rtf',parameter2)+10**-15
Freqs1[4,:]=train(Train_address+'FT_P1.rtf',parameter2)+10**-15
Freqs1[5,:]=train(Train_address+'N_Shakespear_Hamlet_P1.rtf',parameter2)+10**-15


Freqs2=np.zeros((len(Texts_Test),128*128))
Freqs2[0,:]=test(Test_address+'N_Sartre_Nausea_P2.rtf')+10**-15
Freqs2[1,:]=test(Test_address+'N_Shakespear_Ceasar_P2.rtf')+10**-15
Freqs2[2,:]=test(Test_address+'News_P2.rtf')+10**-15
Freqs2[3,:]=test(Test_address+'BBC_P2.rtf')+10**-15
Freqs2[4,:]=test(Test_address+'FT_P2.rtf')+10**-15
Freqs2[5,:]=test(Test_address+'N_Shakespear_Hamlet_P2.rtf')+10**-15


G=np.zeros((len(Texts_Train),len(Texts_Test)))
for i in range(0,len(Texts_Train)):
    for j in range(0,len(Texts_Test)):
            G[i][j]=math.exp(IT.KLD(Freqs1[j,:],Freqs2[i,:]))

L= len(Texts_Train)+len(Texts_Test)

min_of_rows = G.min(axis=1)
G = G/ min_of_rows[:, np.newaxis]
G=np.reciprocal(G)
#G=G**6
G_Graph=np.zeros((L,L))
G_Graph[len(Texts_Train):L,0: len(Texts_Train)]=G
G_Graph[0: len(Texts_Train),len(Texts_Train):L]=np.transpose(G)







def show_graph_with_labels(adjacency_matrix, mylabels):
    gr = nx.Graph() #Create a graph object called G
    node_list = mylabels
    for node in node_list:
        gr.add_node(node)
    pos=nx.circular_layout(gr)
    plt.figure(6,figsize=(50,50))
    nx.draw_networkx_nodes(gr,pos,node_color='green',node_size=100)
    labels = {}
    for node_name in node_list:
        labels[str(node_name)] =str(node_name)
    nx.draw_networkx_labels(gr,pos,labels,font_size=40)
    rows, cols = np.where(adjacency_matrix >0)
    a=rows.tolist()
    b=cols.tolist()
    for i in range(0,len(a)):
        gr.add_edge(node_list[a[i]],node_list[b[i]],weight=adjacency_matrix[a[i],b[i]])
    all_weights=list([])
    for (node1,node2,data) in gr.edges(data=True):
        all_weights.append(data['weight'])
    unique_weights=list(set(all_weights))
    for weight in unique_weights:
        weighted_edges=[(node1,node2) for (node1,node2,edge_attr) in gr.edges(data=True) if edge_attr['weight']==weight]
        width=weight*5*len(adjacency_matrix)/sum(all_weights)
        nx.draw_networkx_edges(gr,pos,edgelist=weighted_edges,width=width)
    plt.show()
    plt.savefig( datetime.now().strftime("%Y%m%d-%H%M%S"), dpi=300, bbox_inches='tight')
 
    print(1)
   

show_graph_with_labels(G_Graph, Texts_Range)

# print(IT.KLD(Freqs_Sartre_1,Freqs_Sartre_2))
# print(IT.KLD(Freqs_Ceasar_1,Freqs_Sartre_2))
# print(IT.KLD(Freqs_Hill_1,Freqs_Sartre_2))
# print(IT.KLD(Freqs_BBC_1,Freqs_Sartre_2))
# print(IT.KLD(Freqs_FT_1,Freqs_Sartre_2))
# print(IT.KLD(Freqs_Hamlet_1,Freqs_Sartre_2))


# print('-----------')
# print(IT.KLD(Freqs_Sartre_1,Freqs_Ceasar_2))
# print(IT.KLD(Freqs_Ceasar_1,Freqs_Ceasar_2))
# print(IT.KLD(Freqs_Hill_1,Freqs_Ceasar_2))
# print(IT.KLD(Freqs_BBC_1,Freqs_Ceasar_2))
# print(IT.KLD(Freqs_FT_1,Freqs_Ceasar_2))
# print(IT.KLD(Freqs_Hamlet_1,Freqs_Ceasar_2))

# print('-----------')
# print(IT.KLD(Freqs_Sartre_1,Freqs_Hill_2))
# print(IT.KLD(Freqs_Ceasar_1,Freqs_Hill_2))
# print(IT.KLD(Freqs_Hill_1,Freqs_Hill_2))
# print(IT.KLD(Freqs_BBC_1,Freqs_Hill_2))
# print(IT.KLD(Freqs_FT_1,Freqs_Hill_2))
# print(IT.KLD(Freqs_Hamlet_1,Freqs_Hill_2))

# print('-----------')
# print(IT.KLD(Freqs_Sartre_1,Freqs_BBC_2))
# print(IT.KLD(Freqs_Ceasar_1,Freqs_BBC_2))
# print(IT.KLD(Freqs_Hill_1,Freqs_BBC_2))
# print(IT.KLD(Freqs_BBC_1,Freqs_BBC_2))
# print(IT.KLD(Freqs_FT_1,Freqs_BBC_2))
# print(IT.KLD(Freqs_Hamlet_1,Freqs_BBC_2))

# print('-----------')
# print(IT.KLD(Freqs_Sartre_1,Freqs_FT_2))
# print(IT.KLD(Freqs_Ceasar_1,Freqs_FT_2))
# print(IT.KLD(Freqs_Hill_1,Freqs_FT_2))
# print(IT.KLD(Freqs_BBC_1,Freqs_FT_2))
# print(IT.KLD(Freqs_FT_1,Freqs_FT_2))
# print(IT.KLD(Freqs_Hamlet_1,Freqs_FT_2))

# print('-----------')
# print(IT.KLD(Freqs_Sartre_1,Freqs_Hamlet_2))
# print(IT.KLD(Freqs_Ceasar_1,Freqs_Hamlet_2))
# print(IT.KLD(Freqs_Hill_1,Freqs_Hamlet_2))
# print(IT.KLD(Freqs_BBC_1,Freqs_Hamlet_2))
# print(IT.KLD(Freqs_FT_1,Freqs_Hamlet_2))
# print(IT.KLD(Freqs_Hamlet_1,Freqs_Hamlet_2))
# print('-----------')


